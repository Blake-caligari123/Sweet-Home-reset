# Puff animation: repo tasks (frame-based pixel art, updated 27 Oct 2026)
Repo: github.com/Blake-caligari123/Sweet-Home-reset · PixiJS v8 · source art: art/puff/ (reference: #01 puff_model_sheet). Replaces the old code-rig plan (no squash and stretch, no scale tweens).
All frames are 48×48 px on the shared grid from `tools/process_asset.py --pixel puff`, palette `tools/palette24.json`, 1 px #8A6E5E outline, feet on one baseline. One `PuffSprite` (Pixi `AnimatedSprite`, nearest-neighbour, whole-pixel positions) plays named clips:
1. Idle: 4 frames from sheet #100 `puff_idle_sheet`, looping (~6 fps, tune in `config/tuning.json`).
2. Blink: 2 frames from sheet #101 `puff_blink_sheet`, played over idle at random every 2.5–6 s; double-blink 15%.
3. Hop: 6 frames from sheet #102 `puff_hop_sheet`, on task done / stage-up / reveal.
4. Walk: 6 frames per direction from sheets #97 `puff_walk_down`, #98 `puff_walk_up`, #99 `puff_walk_right`; left = #99 mirrored (`scale.x = -1`, no extra file). Returns to idle when Puff stops.
5. Mood/state poses (#02–#14, e.g. sleepy, proud_spin, party) are frame clips on the same 48 px grid; `setMood()` swaps the clip.
Reduced motion: idle holds frame 1, blinks still play, hop plays once without travel.
AT: every clip plays at 60 fps render on iPhone 12-class with no sub-pixel blur; left walk is a mirror of right; reduced motion verified; a missing sheet falls back to code-drawn Puff.
Sources: idle/blink/hop = frame sheets #100–102 (added 27 Oct 2026); walk = #97–99.
