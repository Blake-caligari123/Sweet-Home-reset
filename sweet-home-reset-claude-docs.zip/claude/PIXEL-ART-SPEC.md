# Pixel-art pass spec (for tools/process_asset.py, built by BB Builder)

Status: approved by Blake 27 Oct 2026. Engine rendering rules: FRONTEND-PLAN.md §15.

## Pipeline step (flag: --pixel room|puff|prop)
1. Remove watermark and background as now (never overwrite .jpg).
2. Crop to content, then nearest-neighbour downscale: rooms to 180x390 portrait (generate at 9:19.5), Puff frames to 48x48 per frame (walk sheets 6x48 wide), props to whole multiples of 16 px.
3. Quantize to the shared 24-colour palette (tools/palette24.json); no dithering.
4. Despeckle: remove isolated single pixels and 1-px colour islands.
5. Alpha: hard 0/255 only (no soft edges).
6. Outline: 1-px #8A6E5E on cutouts (characters, props), not on room backgrounds.
7. Upscale x4 nearest-neighbour for export; keep 1x copy for the engine.
8. Dirty/clean pairs: process the clean image first and reuse its crop and scale for the dirty one so pixels line up; the scrub mask snaps to the 1x grid.
9. Log to LICENCES.md as now.

## Style block (swapped into all 99 prompts 27 Oct 2026; sage set to the palette24 value)
Cosy top-down pixel art, angled about 45°, furniture seen from above at a slight tilt, characters shown from the front-top. Chunky, readable shapes, crisp hard-edged square pixels, no anti-aliasing, no blur, no gradients, no dithering noise, no painterly texture. Limited warm pastel palette (butter #F6E3A1, sage #A9CDA0, peach #F4C2A8, dusty blue #A9BFD6, cream #FFF8EC, warm grey #CFC6BD, soft brown #B9937A), 1-pixel warm-brown #8A6E5E outlines, flat colour with one shade step, soft top-left light, uncluttered floor space. Original character, not resembling Finch or any existing mascot. Negative: photorealism, watercolour, soft brush, 3D render, text, watermark.

Source rule: generate pixel sources in flat colour with clean outlines (rooms at 9:19.5); the pipeline alone won't fully convert painted art, so expect light hand cleanup per asset.

## Trial
Run on art/rooms/topdown_test_1.jpg; output art/rooms/topdown_test_1_pixel.png (4x) for CEOBOT's before/after. Done 27 Oct 2026 at the old 320×180 grid; re-run at 180×390 is the next step.
