# Step 07: accessibility and local save
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Accessibility pass (reduced motion, 44 pt targets, captions, ARIA live, assist mode) and local-first SaveBlob.

## Files to touch
src/a11y/, src/services/SaveService.ts

## Acceptance tests
FRONTEND F8–F9 ATs; GAME-DESIGN §10 Step 11.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
