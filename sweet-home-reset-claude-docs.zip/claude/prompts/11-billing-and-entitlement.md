# Step 11: billing and entitlement
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
One `plus` entitlement via RevenueCat: Stripe Checkout + webhook + portal on web (founding A$34.99 first year web only), Apple IAP and Play Billing on mobile, 7-day trial, A$7.99/mo, A$44.99/yr (yearly default), grace period, trial reminder, paywall.

## Files to touch
worker/src/billing/, worker/src/revenuecat.ts, src/services/EntitlementService.ts, src/ui/paywall/

## Acceptance tests
BACKEND AT7–AT12, AT15; FRONTEND F15 ATs; prices only from config/pricing.json.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
