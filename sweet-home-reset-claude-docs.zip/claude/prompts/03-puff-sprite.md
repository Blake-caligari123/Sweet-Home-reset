# Step 03: puff sprite
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Frame-based Puff per `claude/PUFF-ANIMATION-TASKS.md`: idle 4, blink 2, hop 6, walk sheets #97–99 (left = #99 mirrored), 4-direction floor walking, code-drawn fallback.

## Files to touch
src/actors/PuffSprite.ts, src/actors/puffStates.ts, config/tuning.json

## Acceptance tests
PUFF-ANIMATION-TASKS ATs; GAME-DESIGN §10 Step 4 ATs; no scale tween/squash anywhere (grep).

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
