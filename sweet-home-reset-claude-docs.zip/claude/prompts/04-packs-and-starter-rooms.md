# Step 04: packs and starter rooms
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Pack schema (Zod v1) and 3 bundled free rooms (kitchen nook, living room, bedroom) using 180×390 dirty/clean PNGs from `public/art/rooms/`.

## Files to touch
src/packs/schema.ts, public/packs-bundled/, packs-src/

## Acceptance tests
FRONTEND F4 ATs; dirty and clean are both 180×390; 20 fuzzed broken packs rejected without crashing.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
