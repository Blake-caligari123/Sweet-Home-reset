# Step 02: pixel stage and scenes
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Scene manager + DOM shell, and the pixel stage: 180×390 logical portrait, largest whole-number scale, floor-colour fill, nearest-neighbour, `roundPixels`. Menu text/buttons stay DOM text with 44 pt targets.

## Files to touch
src/app/, src/scenes/, src/render/pixelStage.ts, src/ui/

## Acceptance tests
FRONTEND F2 ATs; at 375/390/430 px widths the scale is an integer with no blur; safe areas respected; scene switch ×20 leaves texture count at baseline.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
