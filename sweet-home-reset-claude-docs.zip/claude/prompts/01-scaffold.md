# Step 01: scaffold
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Scaffold the repo: Vite + TypeScript + PixiJS v8 client, Hono Worker API with D1, Vitest, Playwright, ESLint, size-limit, `config/pricing.json` and `config/app.json` copied from `claude/config/`.

## Files to touch
package.json, vite.config.ts, src/main.ts, worker/src/index.ts, wrangler.toml, migrations/0001_init.sql, config/*.json, tests/

## Acceptance tests
FRONTEND F1 ATs; BACKEND AT1 (`GET /api/health` 200, migrations apply to empty D1); no price literal outside config/pricing.json; `npm test` and `npm run build` pass.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
