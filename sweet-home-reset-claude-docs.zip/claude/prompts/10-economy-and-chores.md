# Step 10: economy and chores
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Sparkles/Energy ledger, real-chore loop, Mess of the Day seed, shop with fixed prices, finished rooms as decor.

## Files to touch
worker/src/chores.ts, worker/src/daily.ts, src/scenes/ShopScene.ts

## Acceptance tests
BACKEND AT5, AT6, AT4d; FRONTEND F11–F12; GAME-DESIGN §10 Steps 5–7.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
