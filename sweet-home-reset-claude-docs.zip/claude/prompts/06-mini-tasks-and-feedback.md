# Step 06: mini tasks and feedback
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Mini-tasks driven by tuning data, Help Puff, FeedbackService (particles, haptics, WebAudio, captions).

## Files to touch
src/tasks/, src/services/FeedbackService.ts, config/tuning.json

## Acceptance tests
FRONTEND F6–F7 ATs; GAME-DESIGN §10 Step 3.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
