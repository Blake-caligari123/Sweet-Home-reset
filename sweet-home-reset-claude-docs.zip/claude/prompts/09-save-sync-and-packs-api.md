# Step 09: save sync and packs api
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Save/sync with 409 merge, pack catalogue API and client pack loader with versioned cache and offline fallback.

## Files to touch
worker/src/save.ts, worker/src/packs.ts, src/services/PackService.ts

## Acceptance tests
BACKEND AT4, AT4b, AT4c; FRONTEND F10, F14 ATs.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
