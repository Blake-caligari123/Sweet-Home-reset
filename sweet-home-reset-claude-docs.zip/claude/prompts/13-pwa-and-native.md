# Step 13: pwa and native
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
PWA + offline, then Capacitor iOS and Android (appId `com.pixelvortexgames.sweethomereset`), deep links, haptics, back button.

## Files to touch
vite.config.ts (PWA), capacitor.config.ts, ios/, android/, public/.well-known/

## Acceptance tests
FRONTEND F18–F19 ATs. Do not create store accounts or upload builds.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
