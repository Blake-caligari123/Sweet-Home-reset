# Step 14: performance and store readiness
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Profiling, memory soak, store screenshots from the build, IARC/privacy inputs checked against `claude/IARC-ANSWERS.md` and `claude/STORE-PRICES.md`.

## Files to touch
docs/store/, tests/perf/

## Acceptance tests
FRONTEND F20 ATs; GAME-DESIGN §10 Step 12. Uploads to TestFlight/Play only after Blake approves and creates the accounts.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
