# Step 05: scrub reveal
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Scrub reveal on the 1x grid: pointer input, hard-edged pixel brush into RevealRT, progress sampling, 95% auto-finish, stage events 25/50/75/100.

## Files to touch
src/input/, src/scenes/room/DirtLayer.ts, src/scenes/room/progress.ts

## Acceptance tests
FRONTEND F5 ATs; GAME-DESIGN §10 Steps 1–2; revealed cells align to the 180×390 grid.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
