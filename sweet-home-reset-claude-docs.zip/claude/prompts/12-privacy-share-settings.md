# Step 12: privacy share settings
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Export/delete, analytics opt-out, hardening, share clips and cards, Settings (credits line "Some art created with Grok Imagine").

## Files to touch
worker/src/me.ts, worker/src/events.ts, src/services/ShareService.ts, src/scenes/Settings/

## Acceptance tests
BACKEND AT13, AT14, AT17; FRONTEND F16–F17 ATs.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
