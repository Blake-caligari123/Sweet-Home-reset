# Step 08: auth
Read `/CLAUDE.md` first. Write tests first; finish with `npm test` green.

## Goal
Magic-link auth and Sign in with Apple (bundle `com.pixelvortexgames.sweethomereset`, web Services ID `.web`), 16+ age checkbox, sessions, rate limits; client sign-in sheet with secure token storage.

## Files to touch
worker/src/auth/, src/services/AuthService.ts

## Acceptance tests
BACKEND AT2, AT3, AT16; FRONTEND F13 ATs.

## Done when
All tests above pass locally with no keys, nothing is deployed, and the change is handed to QA Group.
