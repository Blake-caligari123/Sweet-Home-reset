# CLAUDE.md: Sweet Home Reset (PixelVortex Games)

## Project
A cosy cleaning game: scrub a messy room back to sparkling with Puff the dust bunny, then do one tiny real chore. v1 ships on **web/PWA, iOS App Store and Google Play together, with no phases**. Bundle ID `com.pixelvortexgames.sweethomereset` (web Services ID `com.pixelvortexgames.sweethomereset.web`). Repo: github.com/Blake-caligari123/Sweet-Home-reset.

## Stack
- Client: TypeScript + Vite + PixiJS v8, DOM overlay UI, Capacitor for iOS/Android, vite-plugin-pwa.
- Server: Cloudflare Pages (static, packs) + Workers (Hono, `/api/*`) + D1; Cron Triggers; Resend free tier for email.
- Payments: one RevenueCat `plus` entitlement. Stripe Checkout on web, Apple IAP on iOS, Play Billing on Android.
- Sign-in: email magic link + Sign in with Apple. Optional; the game is fully playable offline and signed out.
- Prices (only in `config/pricing.json`): A$7.99/mo, A$44.99/yr (yearly default), 7-day trial; founding A$34.99 first year on **web only**.

## Art and animation (approved 27 Oct 2026)
- Angled top-down camera of about 45°: furniture seen from above at a slight tilt, characters from the front-top. Puff walks the floor in 4 directions (left = right mirrored).
- Pixel art per `claude/PIXEL-ART-SPEC.md`: portrait rooms 180×390 (generate at 9:19.5), Puff 48 px frames, `tools/palette24.json` (the only palette), 1px #8A6E5E outlines, nearest-neighbour whole-number scaling with floor-colour fill, scrub reveal snapped to the grid. Menu text and buttons stay crisp DOM text with 44 px tap targets.
- Generate sources in flat colour with clean outlines; the pipeline alone won't fully convert painted art.
- Frame-based Puff: idle 4, blink 2, hop 6, walk sheets #97–99 (`claude/PUFF-ANIMATION-TASKS.md`). No squash and stretch.
- Assets are numbered 01–99 in `claude/ASSET-PROMPTS.md`. Credit "Some art created with Grok Imagine" in Settings > About and the store listing. The Grok mark is removed from game cutouts per Blake's override; the original .jpg files are never edited (`claude/LICENCES.md`).

## Commands
- `npm test` (Vitest, incl. `@cloudflare/vitest-pool-workers`), `npm run build`, `npx playwright test`
- `npm run pack:build {id}`, `npm run pack:preview {id}`
- `npx cap sync`, then build in Xcode / Android Studio
- Art: `tools/.venv/bin/python tools/process_asset.py <asset> --pixel room|puff|prop [--log]` (see `tools/README.md`)

## Folder map
- `claude/`: design and build docs: GAME-DESIGN, FRONTEND-PLAN, BACKEND-PLAN, ASSET-PROMPTS (+ `asset-prompts/01–99`), PIXEL-ART-SPEC, PUFF-ANIMATION-TASKS, LICENCES, STORE-PRICES, IARC-ANSWERS, BUSINESS-IDEAS, `config/` (app.json, pricing.json), `prompts/` (build steps)
- `art/`: source images and processed output (`MANIFEST.md`, `_drafts/`, `puff/`, `rooms/`)
- `tools/`: `process_asset.py`, `palette24.json`, `README.md`
- Root `GAME-DESIGN.md`, `BUILD-SPEC.md`: early concept docs; `claude/` wins where they differ.
- Precedence: BACKEND-PLAN wins on API/data; FRONTEND-PLAN on client; GAME-DESIGN on rules and feel.

## Conventions
- Tests first; each step ends with `npm test` green. Lowercase snake_case asset names; pack room ids use `-`.
- Copy is a kind friend: never "failed", "lost", "overdue"; no body, weight or appearance talk. Puff is never sad because of the player.
- Secrets only in Worker secrets / `.dev.vars` / `.env` (gitignored, chmod 600). Never in code or chat.

## Hard rules
- Accounts are 16+ (age checkbox). No ads, ad SDKs, IDFA, loot boxes, random paid rewards, paid timers or resetting streaks. Scrubbing never costs Energy.
- iOS build never shows or links to web prices.
- Free tiers only. No deploys to production, public releases, account creation or spending without Blake's yes. Stripe test mode only.
- Every change goes through QA Group before it's called done.

## Build prompts
Run in order: `claude/prompts/01-scaffold.md` … `14-performance-and-store-readiness.md`. Each has a goal, files to touch and acceptance tests.

## Open questions (conflicts not settled by current decisions)
1. Room outlines: PIXEL-ART-SPEC says no outline on room backgrounds; `tools/process_asset.py` outlines rooms (strong edges).
2. Sage hex: spec style block had #B7CDB0; `palette24.json` uses #A9CDA0. Prompts now use the palette24 value; confirm.
3. Prop grid: spec says multiples of 16 px; the tool fits all props to 64×64.
4. Paywall cancel line: STORE-PRICES says "Cancel anytime in your App Store / Google Play settings"; FRONTEND-PLAN and BUILD-SPEC say "Cancel anytime in the app".
5. Sharing: IARC-ANSWERS says "shares user content: yes, limited" and mentions a home-tour link; FRONTEND/GAME-DESIGN say no publicly shared user content. Is the home-tour link in v1?
6. Idle 4 / blink 2 / hop 6 sheets have no asset numbers (01–99 is full; only #97–99 are walk sheets).
7. Root BUILD-SPEC still has a streak badge, household sharing and a "1 room free" tier vs claude/ docs (no streaks, 3 free rooms); household sharing in v1 is still open.
8. Store price points A$7.99/A$44.99 are unconfirmed until Blake checks App Store Connect.
