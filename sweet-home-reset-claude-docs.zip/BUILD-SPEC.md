
> **Status 27 Oct 2026:** early concept doc, kept for history. Where it differs, `claude/GAME-DESIGN.md`, `claude/FRONTEND-PLAN.md`, `claude/BACKEND-PLAN.md`, `claude/PIXEL-ART-SPEC.md` and `/CLAUDE.md` win: pixel art (portrait rooms 180×390, Puff 48 px, `tools/palette24.json`, 1px #8A6E5E outlines), angled ~45° top-down camera, frame-based Puff animation, v1 = web + iOS + Google Play with no phases (Capacitor + TypeScript/Vite/PixiJS, Cloudflare Pages/Workers/D1, RevenueCat with Stripe on web, Apple IAP, Play Billing), magic link + Sign in with Apple, 16+ accounts.
## Pricing & Positioning (BB Strategist, 2026-10-27)
**Rivals (sourced in research/2026-10-27-app-ideas.md):** Sweepy 4.7 from about 11K ratings, US$19.99 a year. Tody 4.8 from about 10.7K ratings, US$9.99 to US$80 a year. Both are chore-list utilities. Neither has a cute world you restore or a character people would share.
**Positioning:** "Clean your real home, restore a cosy little world." Every chore you finish restores a room in the game and makes the character happier, and you get a shareable before-and-after card each week. We're a game first and a chore list second, so we take Finch's cosy loop and apply it to cleaning.
**Pricing (my recommendation, an estimate that hasn't been tested):**
- Free: unlimited chore list, 1 room to restore, and the basic character.
- Plus: A$7.99 a month or A$44.99 a year with a 7-day free trial, with annual as the default. It unlocks every room, outfits, seasonal sets, household sharing and the weekly share card.
- Annual is priced above Sweepy because we're the cosy game rather than a utility, but kept well below Finch's US$69.99. Prices are GST-inclusive and set by Ops.
**Paywall rules:** the core loop never sits behind the paywall, and we show the trial end date clearly. backincolor's study of 1,012 low-star reviews in a similar category found 59% were about price or paywalls.
**What to measure:** trial-to-paid rate and Day-7 retention. Revisit the price after the first 100 trials.

## Growth: names and launch content plan (BB Growth, 27 Oct 2026)

### Three name options (not yet checked for trade marks, App Store names or handles; Strategist/Ops to check before Blake picks)
1. ~~Tidy Nook~~: dropped, because it clashes with existing iOS games and a live site (see NAME-CHECK.md).
2. ~~Dustbunny~~: dropped, because it clashes with an existing iOS publisher and a live site. The mascot can still be a dust bunny.
3. **Sweet Home Reset**: plays on #CleanTok "reset" videos and is easy to search. It is clear on the App Store. IP Australia, Google Play and social handles still need checking.
4. **Fluffle Home** (new, unchecked): named after the dust-bunny mascot (a "fluffle" is a group of bunnies).
5. **Cosy Reset** (new, unchecked): short, and matches "reset" content.

### Brand and in-app hooks the build needs (for the spec)
- A shareable "room restored" card (9:16) after each finished room, with the app name, a streak count and no personal data.
- A weekly recap card: tasks done, rooms restored and the streak.
- A "before and after" pair of the *virtual* room, never photos of the user's real home unless they choose to add one.
- An invite link with a referral reward (for example, a free cosmetic item for both people). No cash rewards.

### Launch content plan ($0 and organic; nothing is posted without Blake's yes)
- **Channels:** TikTok, Instagram Reels and YouTube Shorts, under PixelVortex Games or the app's own handle (Blake makes the accounts).
- **Before launch (2 weeks):** daily 15–30s clips: "cleaning my real room to fix my cosy virtual one", room-restore timelapses, a mascot reacting to a messy room, plus a waitlist link with consent and Spam Act–compliant opt-in.
- **Launch week:** a "7-day reset challenge" with a shareable card each day, plus a founding-member yearly price for the first 100 (Strategist sets the price).
- **Ongoing (daily):** one post a day, rotating through restore timelapses, "rate my reset", a cleaning tip with the mascot, user cards (with permission) and new room or decor drops.
- **Communities:** Blake posts himself where the rules allow (for example, relevant subreddits' self-promo threads). No spam or fake accounts.
- **Rules:** no fake reviews or invented numbers, no naming competitors in ads, the locked renewal and cancel wording on every price mention, and 16+ age wording, as Ops has set.
- **Measure (real numbers only):** waitlist sign-ups, install-to-trial and trial-to-paid rates, the share rate of restore cards, and referral invites per user, reviewed weekly against the targets in the spec.

## Ops & Compliance (BB Ops & Finance, 27 Oct 2026)
Publisher: PixelVortex Games (Blake's registered business, ABN on file). Every legal page and the footer reads "© PixelVortex Games" and shows the ABN.

### Age
- 16+ only for accounts. Add an age confirmation checkbox at sign-up. There's no social feed, no chat between users and no public profiles, which keeps us clear of the under-16 social media rules.
- No ads aimed at kids. Store and ad listings say 16+.

### Legal pages (must exist before launch)
- /terms: subscription terms, cancel rights, governing law NSW Australia, and a line saying that nothing excludes Australian Consumer Law guarantees.
- /privacy: what's stored (email, chore list, game progress), where it's stored (name the host and its region), no selling data, no AI training on user data, contact email, and the right to access or delete data.
- /refunds: refunds follow ACL. Cancelling stops the next renewal.
- /notices: list third parties (Stripe, the host, analytics if any).
- Footer links to all four on every page. Each one has to return 200 before launch.

### Data and deletion
- Settings has "Export my data" (JSON) and "Delete my account", which deletes the data within 30 days and cancels Stripe.
- No photos in v1. If before/after photos get added later, they stay on the device by default and the privacy page is updated first.
- Analytics are cookieless or opt-in only.

### Stripe subscriptions
- Stripe account in PixelVortex Games' name. Blake does the ID, payout and 2-step steps himself.
- Statement descriptor: PIXELVORTEX* Sweet Home Reset.
- Wording beside the pay button, verbatim: "Renews automatically at A$7.99/month (or A$44.99/year) until you cancel. Cancel anytime in the app." Prices from Strategist (estimates, untested). The prices shown must include any GST.
- Founding-member offer (first 100 annual), verbatim: "A$34.99 for your first year, then renews automatically at A$44.99/year until you cancel. Cancel anytime in the app." Show the A$44.99 renewal price just as clearly as the A$34.99, never in smaller print.
- Free trial (if there is one): show the end date plus "You'll be charged A$7.99 (or A$44.99 for yearly) on [DATE] unless you cancel", and send a reminder email 3 days before the first charge.
- Cancel: one tap in Settings, which opens the Stripe Customer Portal. No retention maze, and access lasts until the period ends.
- Send a receipt email for every charge (Stripe default).

### Game and claims rules
- No real-money loot boxes, gacha or paid random rewards. Cosmetics bought with real money must be shown at a fixed price.
- No health, mental-health or "cures procrastination" claims. "Makes cleaning feel cosy" is fine.
- Streaks must be forgiving: no guilt-trip push notifications, and notifications are opt-in.
- Art is original or commercially licensed and recorded in LICENCES.md. Nothing that copies Finch, Sweepy or Tody art or names. Growth's name options need a trademark check (IP Australia search) before Blake picks one.

### Money and tax
- GST: not registered while turnover is under A$75k. I'll track monthly revenue and flag it at A$60k.
- $0 spend unless Blake approves. Free tiers only, with spend caps on anything metered.

### Support
- Text-only, via a support email on the app's domain. Target a reply within 2 business days. Refund and cancel requests are handled per /refunds.
**Founding-member price (Strategist, an untested estimate):** A$34.99 for the first year for the first 100 annual subscribers, renewing at A$44.99 a year. Ops' renewal wording has to state both prices.

## Build Spec: Tech & Product (BB Builder, 27 Oct 2026)
Paste this whole file into the AI coding tool. Where sections overlap, the Pricing, Growth and Ops sections above win. App name = `Sweet Home Reset` until Blake picks one from Growth's list.

### 1. Product summary and target user
A mobile-first PWA where you tick off real chores at home to earn Sparkles, and spend them to restore and decorate a cute virtual home looked after by an original mascot. Target user: adults 16+ in Australia who want cleaning to feel cosy rather than like a chore list. Sold in A$ with GST included.

### 2. Core loop
1. Open the app and see today's chores, picked by room and frequency.
2. Tick a chore to earn Sparkles (fixed values: quick 5, medium 10, big 20). Every Sparkle is earned by a chore; none are random.
3. Each real room is linked to a virtual room. Finished chores raise that room's clean level from 0 to 100, and each step swaps a dirty SVG layer for a clean one.
4. Spend Sparkles in the shop on decor at fixed, visible prices. Real money only unlocks Plus. There are no loot boxes, gacha or paid random rewards.
5. Streak: one day counts when you finish at least 1 chore. You get 2 free "cosy days" a week that keep the streak alive, and the app never guilt-trips you.
6. Each week ends with a recap share card.

### 3. Screens
- **Onboarding:** 16+ age checkbox, email magic link sign-in, pick rooms (kitchen, bathroom, bedroom, living, laundry, custom), pick a starter chore set per room, and opt in to notifications (off by default).
- **Today:** chores due today grouped by room, tick with an animation and a "+Sparkles" toast, plus the streak badge.
- **Home:** an angled top-down (~45°) pixel-art house overview of all rooms with their clean level. Locked rooms show "Plus".
- **Room view:** a large SVG room with its layers, the room's chores, decor slots, and a "Room restored" 9:16 share card when it reaches 100.
- **Shop and decor:** a fixed-price grid of items, filters, owned items and place-in-slot. Seasonal sets are Plus only.
- **Weekly recap:** a 9:16 card showing chores done, rooms restored, streak and app name, with no personal data. Uses the Web Share API and falls back to PNG download.
- **Settings:** notifications, reminder time, household (Plus), invite link, Export my data (JSON), Delete my account, and links to legal pages.
- **Plan and billing:** current plan, trial end date, the locked Ops wording, Upgrade (Stripe Checkout), and Cancel (one tap to the Stripe Customer Portal).
- Footer on every page: /terms, /privacy, /refunds, /notices, "© PixelVortex Games" and the ABN.

### 4. Free vs Plus (prices from Strategist above; suggested, untested)
| Feature | Free | Plus A$7.99/mo or A$44.99/yr, 7-day trial, annual default |
|---|---|---|
| Unlimited chore list, Today, streaks, reminders | ✓ | ✓ |
| Virtual rooms | 1 | All |
| Mascot | Basic | Outfits |
| Decor shop (earned Sparkles) | Base items | Plus seasonal sets |
| Room-restored card | ✓ | ✓ |
| Weekly recap share card | – | ✓ |
| Household sharing (up to 6 people, shared chores) | – | ✓ |
Referral: an invite link gives both people a free cosmetic item when the invitee finishes onboarding. No cash. Capped at 10 rewards per user.

### 5. Data model (D1 / SQLite)
- `users` (id, email, created_at, age_confirmed_at, plan[free|plus], plan_status[trialing|active|past_due|grace|canceled], plan_period_end, stripe_customer_id, household_id, referral_code, referred_by, notif_opt_in, reminder_time, tz default Australia/Sydney, deleted_requested_at)
- `households` (id, owner_user_id, created_at)
- `rooms` (id, user_id/household_id, type, name, virtual_room_key, clean_level 0–100, created_at)
- `chores` (id, room_id, title, size[quick|medium|big], frequency_days, next_due, archived)
- `completions` (id, chore_id, user_id, completed_at, sparkles)
- `wallet` (user_id, sparkles_balance) plus `ledger` (id, user_id, delta, reason, ref_id, created_at), so every balance can be audited
- `items` (key, name, slot, price_sparkles, tier[free|plus], season), all at fixed prices
- `inventory` (user_id, item_key, placed_room_id, slot)
- `streaks` (user_id, current, best, last_day, cosy_days_used_week)
- `referrals` (id, inviter_id, invitee_id, rewarded_at)
- `stripe_events` (event_id PK, type, processed_at), for idempotency
- `revenue_monthly` (month, gross_aud, refunds_aud), for Ops' GST tracking. Flag at A$60k.
No photos, no free text beyond chore and room names, and nothing about health.

### 6. Character and art system ($0, original)
- Mascot: an original, round dust-bunny-like puff with a small apron and a broom-twig antenna, in a warm palette (cream, sage, peach). It must not resemble Finch's bird or any Sweepy/Tody art. Superseded: game art is now Grok Imagine sources processed into pixel art (claude/PIXEL-ART-SPEC.md, credit "Some art created with Grok Imagine"); hand-coded SVG is only the fallback. Original note: all of it is hand-coded inline SVG paths written in this project, with no tracing and no AI-generated images of existing characters.
- Moods: sleepy, happy, proud and cheering, made by swapping eye and mouth paths. Animation is frame-based pixel sprites (claude/PUFF-ANIMATION-TASKS.md).
- Rooms: each virtual room is one SVG with ordered `<g>` layers: base, furniture, `dirt-*` (dust, clutter, stains, cobwebs), clean sparkle, and decor slots. As clean_level crosses 25/50/75/100, one dirt layer fades out (CSS opacity plus a transform, 400ms) and a sparkle burst plays (JS, about 12 particles). Respect `prefers-reduced-motion`.
- Fonts: OFL-licensed Google Fonts only (e.g. Nunito). Sound effects are optional and must be CC0.
- **Every asset** (font, icon, sound, any third-party SVG) gets a row in `/LICENCES.md`: asset, source URL, licence, commercial use yes, date. Original code-drawn art is logged as "original, © PixelVortex Games". If an asset has no commercial-use licence, it can't ship.

### 7. Stripe subscriptions
- Products: Plus monthly A$7.99 and Plus yearly A$44.99, AUD, GST inclusive, with a 7-day trial on Checkout (`subscription_data.trial_period_days=7`). Statement descriptor: PIXELVORTEX* Sweet Home Reset.
- `POST /api/billing/checkout` creates a Checkout Session (mode=subscription) and redirects to it.
- `POST /api/billing/portal` creates a Customer Portal session, used for Cancel in Settings. Cancel happens at period end.
- `POST /api/stripe/webhook`: verify the signature, store event_id to keep it idempotent, and handle `checkout.session.completed`, `customer.subscription.created|updated|deleted`, `invoice.paid` (also adds to revenue_monthly), `invoice.payment_failed` and `charge.refunded`.
- Grace period: on payment_failed, set status=grace and keep Plus for 7 days while Stripe retries. If it's still unpaid after that, go to free. Progress and items are never deleted, and locked rooms simply freeze.
- Wording beside the pay button, verbatim from Ops: "Renews automatically at A$7.99/month (or A$44.99/year) until you cancel. Cancel anytime in the app." Trial line: "You'll be charged A$[PRICE] on [DATE] unless you cancel." Keep it in one `RENEWAL_COPY` constant. Ops owns the text.
- Trial reminder email 3 days before the first charge (scheduled cron, transactional only).
- Keys live in Worker secrets and are never committed. Use test mode until Blake finishes Stripe setup.

### 8. Tech stack (free tiers, cap anything metered)
- Front end: TypeScript + Vite + PixiJS v8, wrapped with Capacitor for iOS and Google Play, plus the installable web/PWA build, all in v1 (claude/FRONTEND-PLAN.md).
- API: Cloudflare Workers (Hono) and D1. Static files on Cloudflare Pages. Cron Triggers for reminders, grace expiry and deletion jobs.
- Auth: email magic link via the Worker. Email provider: Resend free tier (approved by Blake 2026-10-27, no card on file; listed on /privacy and /notices).
- Required endpoints: `GET /api/me/export` (full JSON of the user's rows) and `DELETE /api/me` (cancel Stripe, mark for deletion, hard-delete within 30 days by cron).

### 9. Notifications
- Opt-in only, via Web Push (VAPID) on the PWA. One daily reminder at the user's chosen time, and a gentle Sunday "your weekly recap is ready".
- Tone: kind, with no streak-loss threats. Example: "The kitchen bunny would love a quick tidy 🌿".
- Quiet hours run 9pm–8am Australia/Sydney by default. One tap in Settings turns everything off.

### 10. Analytics
- Cookieless first-party analytics (Cloudflare Web Analytics, or events in D1). Events: signup, onboarding_done, chore_done, room_restored, share_card_shared, invite_sent, trial_started, trial_converted, canceled.
- Send no email, chore names or user IDs to ad platforms. No ad pixels in v1. If Blake later approves ads, only anonymous conversion events can go, and only after Ops signs off.

### 11. Acceptance tests (must all pass)
1. Sign-up is blocked without the 16+ checkbox.
2. Ticking a chore adds exactly its fixed Sparkles to the ledger, and the balance equals the sum of the ledger.
3. Crossing 25/50/75/100 removes the right dirt layer, and 100 offers the room-restored card.
4. A free user can't open a second room or the weekly card and sees the Plus upsell, while the core loop still works.
5. The shop shows a fixed price on every item, and no code path gives a random reward for money.
6. Checkout in test mode turns on a trial with the end date shown. The renewal wording appears verbatim next to the pay button.
7. A replayed webhook event is ignored (idempotency). A failed payment goes to grace with Plus kept for 7 days, then drops to free, and data is kept.
8. Cancel in Settings opens the Portal, and access lasts until period_end.
9. `/api/me/export` returns all of the user's data. `DELETE /api/me` cancels Stripe and the cron purges the data within 30 days.
10. /terms, /privacy, /refunds and /notices return 200, and the footer is on every page.
11. Notifications are off until opted in, and no push is sent during quiet hours.
12. A referral rewards both people with a cosmetic exactly once, with no cash.
13. The share cards hold no email or real-home photo.
14. The app works offline for ticking and syncs on reconnect, and Lighthouse PWA is installable.
15. LICENCES.md lists every non-original asset with a commercial-use licence.

### 12. Build order (superseded: v1 ships web + iOS + Google Play with no phases; ordered prompts in claude/prompts/)
- **Week 1 (core):** scaffold Workers, D1 and the PWA. Then auth and the age gate, onboarding, chores and Today, Sparkles and the ledger, one SVG room with dirt-to-clean swaps, the mascot, streaks, and the legal page shells.
- **Week 2 (money and polish):** all rooms, the shop and decor, Stripe (checkout, webhook, grace, portal), the share cards and referral, export and delete, push reminders, analytics, and acceptance tests 1–15.
- (Old phase-2 list removed: founding A$34.99 web-only offer and trial reminder email are v1; household sharing and seasonal-set tiering are open questions in /CLAUDE.md.)
- Launch only after Blake approves and Ops signs off.

## Ops section (BB Ops & Finance to fill)
_See "Ops & Compliance" above. Ops adds anything else here._

### Founding-member offer (tech, BB Builder 2026-10-27)
- Stripe: annual price A$44.99 with a one-time "FOUNDING100" coupon (A$10 off, first invoice only, max_redemptions 100), giving A$34.99 for year one, web only. The checkout shows both prices using Ops renewal wording. A server-side counter hides the offer once 100 are redeemed.

### Growth backup names (27 Oct 2026, none checked yet; for use only if Sweet Home Reset fails the full check)
- **Sparkle Nest**: a cosy home that sparkles once it's clean.
- **Homebun**: a home plus the bun mascot, short and cute.
- **Little Reset Lane**: a cosy street of rooms you restore, which keeps the "reset" hook.
