# Name check — 2026-10-27 (AEDT)
Sources: iTunes Search API (US store), HTTP check of .com. NOT VERIFIED: IP Australia trade marks (search page is JS-rendered, results not readable by curl), Google Play, social handles, .com WHOIS.

| Name | App Store | .com | Verdict |
|---|---|---|---|
| Tidy Nook | "Tidy Nook: Cozy Rooms" https://apps.apple.com/us/app/tidy-nook-cozy-rooms/id6810053531 ; "Tidy Nook: Fit & Tidy Rooms" https://apps.apple.com/us/app/tidy-nook-fit-tidy-rooms/id6811343417 ; "Tidy Nook AI" https://apps.apple.com/us/app/tidy-nook-ai/id6762737446 | tidynook.com resolves (HTTP 200) | CLASH: same name, same cosy-room tidy genre |
| Dustbunny / Dust Bunny | "Dustbunny: Emotions to Plants" by Dustbunny Game, LLC https://apps.apple.com/us/app/dustbunny-emotions-to-plants/id6446886499 | dustbunny.com resolves (HTTP 200) | CLASH: existing wellbeing game from a company named Dustbunny Game, LLC |
| Sweet Home Reset | No exact or near match in top results | sweethomereset.com did not respond (possibly unregistered; unverified) | CLEAR on App Store; TM, Play and handles still unchecked |

Next: Blake (or someone with a browser) should run https://search.ipaustralia.gov.au/trademarks/search/quick on "Sweet Home Reset" in classes 9/41/42 before choosing it.

## Round 2 (2026-10-27 06:07, quick searches only)
- IP Australia: Sweet Home Reset, Tidy Nook, Dustbunny, Fluffle Home and Cosy Reset each returned 0 results. "Dust Bunny" has one live mark, 2460559 "Dust Bunnies Cleaning" in class 37. Its other two results are removed or lapsed.
- Google Play: no exact app match for Sweet Home Reset, Fluffle Home or Cosy Reset. "Fluffle" is already used by several apps, including Fluffle: Bunny Idle Clicker.
- Instagram: @sweethomereset and @flufflehome look free. @cosyreset is taken by "The Cosy Reset".
- TikTok: not checked. Every profile page returned a 403 error, so these need checking by hand.
- Verdict: Sweet Home Reset is the cleanest of the five. Fluffle Home overlaps with other apps' names. Cosy Reset has a taken Instagram handle.
