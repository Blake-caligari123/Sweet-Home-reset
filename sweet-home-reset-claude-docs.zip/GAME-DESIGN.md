# Sweet Home Reset — Game Design Plan
> **Status 27 Oct 2026:** early concept doc, kept for history. Where it differs, `claude/GAME-DESIGN.md`, `claude/FRONTEND-PLAN.md`, `claude/BACKEND-PLAN.md`, `claude/PIXEL-ART-SPEC.md` and `/CLAUDE.md` win: pixel art (portrait rooms 180×390, Puff 48 px, `tools/palette24.json`, 1px #8A6E5E outlines), angled ~45° top-down camera, frame-based Puff animation, v1 = web + iOS + Google Play with no phases (Capacitor + TypeScript/Vite/PixiJS, Cloudflare Pages/Workers/D1, RevenueCat with Stripe on web, Apple IAP, Play Billing), magic link + Sign in with Apple, 16+ accounts.
*PixelVortex Games · owner BB Builder · v1 2026-10-27. Growth and Strategist can add sections at the end.*

## 1. The pitch in one breath
You clean your real home; a little world on your phone gets cleaner with you. Every real chore you tick off wipes dust off a cosy illustrated room, wakes it up, and makes your mascot happier. No guilt, no timers, no losing. Just a soft "ahh" every time you finish something.

## 2. Core loop (about 2 minutes in the app, any amount of time off it)
1. **Open** → your mascot greets you in today's room, which has a light layer of dust.
2. **Pick** 1–3 chores from a short suggested list (or add your own): "Wipe the bench", "5-minute floor pickup", "Wash the mugs".
3. **Go do it** in real life. Optional cosy timer with soft music.
4. **Tick it** → satisfying sweep animation: dust puffs away, sparkles, a little chime.
5. **Room progresses** a stage. Mascot reacts. You collect **Sparkles** (soft currency).
6. **Spend Sparkles** on a decor item for the room, or save up. Close the app feeling good.

The loop is complete even with ONE chore. That's the point: tiny wins count.

## 3. How real chores become progress
- **Dust**: each room has a dust level from 0 to 100. Chores remove dust by size: Quick (2–5 min) = 10, Medium (10–20 min) = 25, Big (30+ min) = 40.
- **Stages**: every room has 4 visible stages, at 25%, 50%, 75% and 100% clean.
  - 25%: the curtains open and light comes in.
  - 50%: the colours warm up and a plant perks up.
  - 75%: small details appear, like steam from a mug or a cat on the rug.
  - 100%: the room "sparkles", a short celebration plays, a decor reward is unlocked and the room is kept forever.
- **Gentle re-dust**: finished rooms gather a *little* dust again over days (cosmetic only, never lost), so returning to tidy feels natural, like real life. Nothing is ever taken away.
- **Honesty, not policing**: we trust the player. No photo proof required. Optional "before/after" photo stays on device.

## 4. A daily session
- Morning or evening, about 1–3 minutes in app.
- The mascot suggests a tiny "Reset of the day" (3 quick chores matched to the current room).
- Do any number. Finishing the daily three gives a bonus Sparkle jar and a mascot moment (dance, nap, hat).
- Bad day? Tap "Just one thing" and the game picks the easiest chore. One tick still counts as showing up.

## 5. The mascot: Puff
- A round, soft dust bunny who *used to be* the dust and became your friend once you started cleaning. Slightly clumsy, very proud of you, easily delighted. Original design (pixel art, see claude/PIXEL-ART-SPEC.md), nothing like Finch's bird or any existing pet app.
- **Personality**: warm, encouraging, never nagging. Talks in short lines: "Oh! The window! I can see the sky!" / "No rush. I'll be here, napping on the couch."
- **Moods**: sleepy, cosy, bouncy, proud. Shown by frame-based pixel poses, ears and eye shape. Puff is NEVER sad or sick because you skipped a day.
- **Customise**: hats, scarves, colours and little sidekicks (a sock, a spoon) earned with Sparkles.

## 6. Rooms and unlock path
Start in a tiny flat, and your home grows as you go. Each room unlocks when the previous one reaches 100%, or after 5 days of play, whichever comes first, so nobody gets stuck.
1. Kitchen nook (tutorial)
2. Living room
3. Bedroom
   (free path ends here; seasonal event rooms are also free while they run)
4+. Plus: Bathroom, Laundry, Entry / hallway, Balcony garden, then premium homes: Seaside cottage, Treehouse, Snowy cabin, City loft, with new chore packs and seasonal themes.

Rooms map to real rooms in your home ("Which rooms do you have?" during onboarding), so chores feel relevant.

## 7. Art style, cosy feel and sound
- **Look**: cosy pixel art, angled top-down camera of about 45° (furniture from above at a slight tilt, characters from the front-top), warm pastels from `tools/palette24.json`, 1px #8A6E5E outlines, one portrait room per screen (claude/PIXEL-ART-SPEC.md).
- **Dust** is a soft grey haze with floating motes, never gross. Cleaning *reveals* colour.
- **Motion**: frame-based sprite animation (claude/PUFF-ANIMATION-TASKS.md), sparkle bursts, 60fps PixiJS.
- **Sound**: lo-fi acoustic loop (licensed or original, logged in LICENCES.md), soft broom swish, glassy chime on stage-up, a tiny "pff" from Puff. Haptics on tick. Everything mutable, and silent mode looks just as good.
- **Tone of copy**: like a kind friend. Never "You failed", "Streak lost" or "Overdue".

## 8. Streaks and gentle retention (never punishes)
- **Cosy Days** instead of a streak: a count of days you showed up, which only goes up and never resets.
- **Weekly Glow**: do something on 3 of 7 days and the house gets a weekly glow plus a bonus. Missing days just means a smaller glow.
- **Rest days are built in**: tell Puff "rest day" and it counts as showing up.
- **Welcome back**: after time away, Puff throws a tiny party ("You're back!"), with no dust pile-up shame.
- **Reminders**: optional, one a day at most, at the time you choose, in Puff's voice ("Puff found a sunny spot. Want to do one tiny thing?").

## 9. Free vs paid
**Free forever**: Puff, the first 3 rooms plus free seasonal event rooms, unlimited chores, Cosy Days, Weekly Glow, a basic decor set, sharing.
**Sweet Home Reset Plus** (A$7.99/mo or A$44.99/yr, annual default, 7-day free trial; founding members A$34.99 for year one):
- Premium homes and seasonal themes (new every month or so)
- The full decor and Puff wardrobe catalogue, plus double Sparkles
- Custom routines and chore packs (deep clean, moving house, kids' jobs, pet care)
- Household sharing (up to 4 people cleaning the same home)
- Extra music and ambience tracks

No loot boxes, no random paid rewards, no ads, and nothing that makes the free version feel broken.

## 10. Share moments
- **Before/After card**: the dusty room beside the sparkling one, with Puff and "Reset done ✨". Made for TikTok and Instagram stories, using the app's own art, not your real home unless you choose to add it.
- **Room complete** celebration screen, saved as an image or a short looping clip.
- **Weekly Glow recap**: "This week you did 14 tiny things."
- **Invite a housemate**: both of you get a cosmetic gift (cosmetic only).

## 11. The first 10 minutes
| Time | What happens |
|---|---|
| 0:00 | Soft open: a dusty little kitchen, a grey fluffball sneezes, the music fades in. |
| 0:20 | Puff pops out: "Oh! Someone's home!" Name your home (optional). |
| 0:45 | "Which rooms do you have?" Tap icons. "How much energy do you have most days?" Low, Some or Lots, which sets chore sizes. |
| 1:30 | First chore, suggested and tiny: "Put 5 things where they belong." The timer is optional. |
| ~4:00 | Tick it: the big first sweep and sparkle, and the curtains open (25% stage). Puff bounces. |
| 4:30 | First Sparkles, so place your first decor item (a plant). Teaches the shop. |
| 5:30 | Second quick chore offered, or "That's plenty for today, honestly." Both are fine. |
| 7:00 | Optional reminder setup in Puff's voice; pick a time or skip. |
| 8:00 | Peek at the locked living room ("clean the kitchen to open it"). |
| 9:00 | Share card for your first stage-up, offered once. |
| 10:00 | Puff curls up for a nap: "See you next time. No rush." |

**Plus pitch timing**: shown first when the player fully restores their first room (celebration, then a gentle "start 7-day free trial" option that can be skipped), not in the first 10 minutes.

The goal of the first session is one real chore done, one room stage cleared, and the player leaving with a warm feeling.

## 12. What we'll measure (no numbers until we have real ones)
Day 1, 7 and 30 return rate, chores ticked per session, trial starts and conversion, and share cards created.

---
*Additions from Growth / Strategist below this line.*

### Strategist notes
- **Why we beat Sweepy and Tody:** they're chore lists you tick off. Sweet Home Reset gives you a world you can see coming back to life, and Puff makes it worth sharing. Every screen should show that visible progress, so it should never feel like a to-do list with a cute skin on it.
- **Free path is too generous (my view, untested):** with 7 free rooms, most players may never need Plus. I suggest 3 free rooms (about 2 to 3 weeks of play) plus seasonal free events. Paid then unlocks the rest of the house, the wardrobe and household sharing. Players still never hit a wall on chores.
- **Plus pitch timing:** at 8 minutes it's too early. Show it the first time a player fully restores a room, which is their moment of pride, and offer the trial then.
- **Measure from day one:** Day-1 and Day-7 return rate, the share rate of the before-and-after card, and trial-to-paid. Revisit the free room count after the first 100 trials.

### Growth additions (BB Growth)
- **Puff's voice is the brand.** Puff has short, warm, slightly cheeky lines ("ooh, we found the floor!") that work as on-screen text in videos, so every clip can star Puff.
- **Made to be filmed.** The room clean-up should be a satisfying 3–5 second animation with a soft chime, so people can screen-record it beside their real clean-up. That split screen is our main TikTok format.
- **Reset Sunday.** An optional weekly themed room or decor drop on Sundays, to match #CleanTok's "Sunday reset" habit. It gives us a reason to post every week and a reason for players to open the app.
- **Shareable home tour.** A read-only link to your decorated home, with no account needed to view it. Each visit is a free ad, and the page shows a "Make your own" button.
- **Invite a friend.** Both people get a cosmetic item, such as a Puff hat. There are no cash rewards and no pressure messages.
